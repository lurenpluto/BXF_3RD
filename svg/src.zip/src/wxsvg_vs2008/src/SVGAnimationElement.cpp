//////////////////////////////////////////////////////////////////////////////
// Name:        SVGAnimationElement.cpp
// Purpose:     
// Author:      Alex Thuering
// Created:     2005/05/10
// RCS-ID:      $Id: SVGAnimationElement.cpp,v 1.2 2005/06/17 13:24:50 ntalex Exp $
// Copyright:   (c) 2005 Alex Thuering
// Licence:     wxWindows licence
//////////////////////////////////////////////////////////////////////////////

#include "SVGAnimationElement.h"

double wxSVGAnimationElement::GetStartTime()
{
  return 0;
}

double wxSVGAnimationElement::GetCurrentTime()
{
  return 0;
}

double wxSVGAnimationElement::GetSimpleDuration()
{
  return 0;
}

