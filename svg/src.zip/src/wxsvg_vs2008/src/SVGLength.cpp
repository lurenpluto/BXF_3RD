//////////////////////////////////////////////////////////////////////////////
// Name:        SVGLength.cpp
// Purpose:     
// Author:      Alex Thuering
// Created:     2005/04/29
// RCS-ID:      $Id: SVGLength.cpp,v 1.5 2005/11/07 17:39:59 ntalex Exp $
// Copyright:   (c) 2005 Alex Thuering
// Licence:     wxWindows licence
//////////////////////////////////////////////////////////////////////////////

#include "SVGLength.h"

std::wstring wxSVGLength::GetValueAsString() const
{
  std::wstring value = wxStringPort::Format(_T("%g"), m_valueInSpecifiedUnits);
  switch (m_unitType)
  {
	case wxSVG_LENGTHTYPE_UNKNOWN: break;
	case wxSVG_LENGTHTYPE_NUMBER: break;
	case wxSVG_LENGTHTYPE_PX: value += _T("px"); break;
	case wxSVG_LENGTHTYPE_PERCENTAGE: value += _T("%"); break;
	case wxSVG_LENGTHTYPE_EMS: value += _T("em"); break;
	case wxSVG_LENGTHTYPE_EXS: value += _T("ex"); break;
	case wxSVG_LENGTHTYPE_CM: value += _T("cm"); break;
	case wxSVG_LENGTHTYPE_MM: value += _T("mm"); break;
	case wxSVG_LENGTHTYPE_IN: value += _T("in"); break;
	case wxSVG_LENGTHTYPE_PT: value += _T("pt"); break;
	case wxSVG_LENGTHTYPE_PC: value += _T("pc"); break;
  }
  return value;
}

void wxSVGLength::SetValueAsString(const std::wstring& n)
{
  m_valueInSpecifiedUnits = 0;
  m_unitType = wxSVG_LENGTHTYPE_NUMBER;
  std::wstring value = wxStringPort::Strip(n, wxStringPort::both);
  std::wstring unit;
  if (value.length()>=2)
  {
	const std::wstring s_numeric = _T("0123456789");
	const std::wstring s_numericFirst = _T("+-.Ee") + s_numeric;
    if (s_numeric.find(value.substr(value.length()-1, 1)) == std::wstring::npos)
	{
        if (s_numericFirst.find(value.substr(value.length()-2,1)) != std::wstring::npos)
	  {
		unit = value.substr(value.length()-1, 1);
		value = value.substr(0, value.length()-1);
	  }
	  else
	  {
		unit = value.substr(value.length()-2, 2);
		value = value.substr(0, value.length()-2);
	  }
	}
  }
  
  double d;
  if (!wxStringPort::ToDouble(value, &d))
	return;
  m_valueInSpecifiedUnits = d;
  
  if (unit.length() == 0);
  else if (unit == _T("px"))
	m_unitType = wxSVG_LENGTHTYPE_PX;
  else if (unit.substr(unit.length()-1, 1) == _T("%"))
	m_unitType = wxSVG_LENGTHTYPE_PERCENTAGE;
  else if (unit == _T("em"))
	m_unitType = wxSVG_LENGTHTYPE_EMS;
  else if (unit == _T("ex"))
	m_unitType = wxSVG_LENGTHTYPE_EXS;
  else if (unit == _T("cm"))
	m_unitType = wxSVG_LENGTHTYPE_CM;
  else if (unit == _T("mm"))
	m_unitType = wxSVG_LENGTHTYPE_MM;
  else if (unit == _T("in"))
	m_unitType = wxSVG_LENGTHTYPE_IN;
  else if (unit == _T("pt"))
	m_unitType = wxSVG_LENGTHTYPE_PT;
  else if (unit == _T("pc"))
	m_unitType = wxSVG_LENGTHTYPE_PC;
  SetValueInSpecifiedUnits(m_valueInSpecifiedUnits);
}

void wxSVGLength::NewValueSpecifiedUnits(wxSVG_LENGTHTYPE unitType, double valueInSpecifiedUnits)
{
  m_unitType = unitType;
  SetValueInSpecifiedUnits(valueInSpecifiedUnits);
}

void wxSVGLength::ConvertToSpecifiedUnits(wxSVG_LENGTHTYPE unitType)
{
  m_unitType = unitType;
}

void wxSVGLength::SetValueInSpecifiedUnits(double n)
{
  m_valueInSpecifiedUnits = n;
  m_value = n;
  switch (m_unitType)
  {
	case wxSVG_LENGTHTYPE_UNKNOWN: break;
	case wxSVG_LENGTHTYPE_NUMBER: break;
	case wxSVG_LENGTHTYPE_PX: break;
	case wxSVG_LENGTHTYPE_PERCENTAGE: break; // todo
	case wxSVG_LENGTHTYPE_EMS: break; // todo
	case wxSVG_LENGTHTYPE_EXS: break; // todo
	case wxSVG_LENGTHTYPE_CM: m_value *= 35.43307; break;
	case wxSVG_LENGTHTYPE_MM: m_value *= 3.543307; break;
	case wxSVG_LENGTHTYPE_IN: m_value *= 90; break;
	case wxSVG_LENGTHTYPE_PT: m_value *= 1.25; break;
	case wxSVG_LENGTHTYPE_PC: m_value *= 15; break;
  }
}
