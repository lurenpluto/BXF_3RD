#include "wxFontPort.h"

#include <assert.h>
#include <bolt/XLGraphic.h>

wxFont::wxFont(void)
{
    m_hFontHandle = NULL;
}

wxFont::wxFont(int size,
       int family,
       int style,
       int weight,
       bool underlined,
       const std::wstring& face,
       wxFontEncoding encoding)
{
    LOGFONT info;
    SetDefault(info);

    //set size
    info.lfHeight = size;

    //set family
    BYTE ff_family;

    // the list of fonts associated with a family was partially
    // taken from http://www.codestyle.org/css/font-family

    switch ( family )
    {
    case wxSCRIPT:
        ff_family = FF_SCRIPT;
        break;

    case wxDECORATIVE:
        ff_family = FF_DECORATIVE;
        break;

    case wxROMAN:
        ff_family = FF_ROMAN;
        break;

    case wxTELETYPE:
    case wxMODERN:
        ff_family = FF_MODERN;
        break;
    case wxSWISS:
    case wxDEFAULT:
    default:
        ff_family = FF_SWISS;
    }

    info.lfPitchAndFamily = (BYTE)(DEFAULT_PITCH) | ff_family;

    //set style
    switch ( style )
    {
    default:
        assert(false);
        // fall through

    case wxFONTSTYLE_NORMAL:
        info.lfItalic = FALSE;
        break;

    case wxFONTSTYLE_ITALIC:
    case wxFONTSTYLE_SLANT:
        info.lfItalic = TRUE;
        break;
    }

    //set weight
    switch ( weight )
    {
    default:
        assert(false);
        // fall through

    case wxFONTWEIGHT_NORMAL:
        info.lfWeight = FW_NORMAL;
        break;

    case wxFONTWEIGHT_LIGHT:
        info.lfWeight = FW_LIGHT;
        break;

    case wxFONTWEIGHT_BOLD:
        info.lfWeight = FW_BOLD;
        break;
    }

    //set underlined
    info.lfUnderline = underlined;

    //set facename
    wcsncpy(info.lfFaceName, face.c_str(), LF_FACESIZE);
    info.lfFaceName[LF_FACESIZE - 1] = '\0';
    //set encoding
    info.lfCharSet = (BYTE)DEFAULT_CHARSET;

    m_hFontHandle = ::CreateFontIndirect(&info);
}

wxFont::~wxFont(void)
{
    DeleteObject(m_hFontHandle);
}

HFONT wxFont::GetResourceHandle()
{
    return m_hFontHandle;
}

void wxFont::SetDefault(LOGFONT& info)
{
    ::memset(&info, 0, sizeof(info));

    info.lfPitchAndFamily = 0;
    info.lfCharSet = DEFAULT_CHARSET ;
    info.lfClipPrecision = CLIP_DEFAULT_PRECIS ;
    info.lfEscapement = 0 ;

    XL_GetDefaultFaceName(info.lfFaceName, LF_FACESIZE);

    info.lfHeight = 12 ;
    info.lfItalic = FALSE ;
    info.lfOrientation = 0 ;
    info.lfOutPrecision = OUT_TT_ONLY_PRECIS ;
    info.lfQuality = DEFAULT_QUALITY ;
    info.lfStrikeOut = FALSE ;
    info.lfUnderline = FALSE ;
    info.lfWeight = FW_NORMAL ;
    info.lfWidth = 0;
}
