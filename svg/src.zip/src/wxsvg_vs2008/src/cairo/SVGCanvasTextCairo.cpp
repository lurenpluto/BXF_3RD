//////////////////////////////////////////////////////////////////////////////
// Name:        SVGCanvasTextCairo.h
// Purpose:     Cairo canvas text
// Author:      Alex Thuering
// Created:     2011/06/23
// RCS-ID:      $Id: SVGCanvasTextCairo.cpp,v 1.11 2013/04/02 06:29:19 ntalex Exp $
// Copyright:   (c) 2011 Alex Thuering
// Licence:     wxWindows licence
//////////////////////////////////////////////////////////////////////////////

#include "SVGCanvasTextCairo.h"
#include "SVGCanvasPathCairo.h"
#include "wxFontPort.h"
#include <wx/tokenzr.h>
#include <cairo/cairo.h>
#if defined(__WXMSW__)
#include <cairo/cairo-win32.h>
#elif defined(__WXMAC__) 
#include <cairo/cairo-quartz.h>
#else
#include <pango/pangocairo.h>
#endif

static void Unicode_to_UTF8(const wchar_t* in, int len, std::string& out)
{
    size_t out_len = len * 3 + 1;
    char* pBuf = new char[out_len];
    if ( NULL == pBuf )
    {
        return;
    }
    char* pResult = pBuf;
    memset(pBuf, 0, out_len);

    out_len = ::WideCharToMultiByte(CP_UTF8, 0, in, len, pBuf, len * 3, NULL, NULL);
    out.assign( pResult, out_len );
    delete [] pResult;
    pResult = NULL;
    return;
}

wxSVGCanvasTextCairo::wxSVGCanvasTextCairo(wxSVGCanvas* canvas): wxSVGCanvasText(canvas) {
}

wxSVGCanvasTextCairo::~wxSVGCanvasTextCairo() {
}

void wxSVGCanvasTextCairo::InitText(const std::wstring& text, const wxCSSStyleDeclaration& style, wxSVGMatrix* matrix) {
	BeginChar(matrix);
	
	// create path from text
	cairo_t* cr = ((wxSVGCanvasPathCairo*) m_char->path)->GetCr();

	int size = (int) style.GetFontSize();
	int fstyle = style.GetFontStyle() == wxCSS_VALUE_ITALIC ? wxFONTSTYLE_ITALIC
			: (style.GetFontStyle() == wxCSS_VALUE_OBLIQUE ? wxFONTSTYLE_SLANT : wxFONTSTYLE_NORMAL);
	wxFontWeight weight = style.GetFontWeight() == wxCSS_VALUE_BOLD ? wxFONTWEIGHT_BOLD
			: style.GetFontWeight() == wxCSS_VALUE_BOLDER ? wxFONTWEIGHT_MAX
			: style.GetFontWeight() == wxCSS_VALUE_LIGHTER ? wxFONTWEIGHT_LIGHT : wxFONTWEIGHT_NORMAL;
	wxFont fnt(size, wxFONTFAMILY_DEFAULT, fstyle, weight, false, style.GetFontFamily());

	HFONT hfont = (HFONT) fnt.GetResourceHandle();
	cairo_set_font_face(cr, cairo_win32_font_face_create_for_hfont(hfont));

	cairo_set_font_size(cr, style.GetFontSize());
	
	cairo_font_extents_t fextents;
	cairo_font_extents(cr, &fextents);
	
	double maxWidth = 0;
	if (style.GetTextAnchor() == wxCSS_VALUE_MIDDLE || style.GetTextAnchor() == wxCSS_VALUE_END) {
		wxStringTokenizer tokenzr(text, _T("\n"));
		while (tokenzr.HasMoreTokens()) {
			std::wstring token = tokenzr.GetNextToken();
			cairo_text_extents_t extents;
            std::string utf8;
            Unicode_to_UTF8(token.c_str(), token.length(), utf8);
			cairo_text_extents(cr, (const char*) utf8.c_str(), &extents);
			if (maxWidth < extents.width)
				maxWidth = extents.width;
		}
	}
	
	wxStringTokenizer tokenzr(text, _T("\n"));
	double x_advance = 0;
	double width = 0;
	double height = 0;
	double y = 0;
	while (tokenzr.HasMoreTokens()) {
		std::wstring token = tokenzr.GetNextToken();
		
		// get text extents
		cairo_text_extents_t extents;
        std::string utf8;
        Unicode_to_UTF8(token.c_str(), token.length(), utf8);
		cairo_text_extents(cr, (const char*) utf8.c_str(), &extents);
		double x = style.GetTextAnchor() == wxCSS_VALUE_END ? maxWidth - extents.width
				: style.GetTextAnchor() == wxCSS_VALUE_MIDDLE ? (maxWidth - extents.width) / 2 : 0;
		
		m_char->path->MoveTo(m_tx + x, m_ty + y);
		cairo_text_path(cr, (const char*) utf8.c_str());
		
		if (x_advance < extents.x_advance)
			x_advance = extents.x_advance;
		if (width < extents.width)
			width = extents.width;
		height += fextents.height;
		if (tokenzr.HasMoreTokens())
			y += fextents.height;
	}
	
	// set bbox
	m_char->bbox = wxSVGRect(m_tx, m_ty, width, height);
	
	// increase current position (m_tx)
	wxSVGRect bbox = m_char->path->GetResultBBox(style);
	m_tx += x_advance > bbox.GetWidth() ? x_advance : bbox.GetWidth();
}
