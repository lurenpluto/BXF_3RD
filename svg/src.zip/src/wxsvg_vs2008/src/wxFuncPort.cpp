#include "wxFuncPort.h"

namespace wxFuncPort{
bool wxFileExists (const std::wstring& filename)
{
    // we must use GetFileAttributes() instead of the ANSI C functions because
    // it can cope with network (UNC) paths unlike them
    DWORD ret = ::GetFileAttributes(filename.c_str());

    return (ret != INVALID_FILE_ATTRIBUTES) && !(ret & FILE_ATTRIBUTE_DIRECTORY);
}
}//namespace wxFuncPort