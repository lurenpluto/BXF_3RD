#include "wxImage.h"

wxImage::wxImage(void)
:m_hBitmapHandle(NULL),
m_height(0),
m_width(0),
m_buffer(NULL)
{
}

wxImage::wxImage(wxImage& image)
{
    m_hBitmapHandle = image.m_hBitmapHandle;
    m_height = image.m_height;
    m_width = image.m_width;
    m_buffer = image.m_buffer;
    image.m_hBitmapHandle = NULL;
    image.m_buffer = NULL;
}

wxImage::~wxImage(void)
{
    Clear();
}

void wxImage::Create(int width, int height)
{
    Clear();
    
    m_hBitmapHandle = XL_CreateBitmap(XLGRAPHIC_CT_ARGB32, width, height);
    m_width = width;
    m_height = height;
}

void wxImage::Create(const unsigned char* buffer, int width, int height)
{
    Clear();
    //m_buffer = new unsigned char[width*height*4];
    //::memcpy(m_buffer, buffer, width*height*4);

    /*
    XLBitmapInfo info;
    info.ColorType = XLGRAPHIC_CT_ARGB32;
    info.Width = width;
    info.Height = height;
    info.ScanLineLength = 0;
    m_hBitmapHandle = XL_CreateBindBitmapEx(&info, m_buffer, TRUE);
    */
    m_hBitmapHandle = XL_CreateBitmap(XLGRAPHIC_CT_ARGB32, width, height);
    unsigned char* bitmapbuf = XL_GetBitmapBuffer(m_hBitmapHandle, 0, 0);
    ::memcpy(bitmapbuf, buffer, width*height*4);
    m_width = width;
    m_height = height;
}

void wxImage::Clear()
{
    if (m_hBitmapHandle)
    {
        XL_ReleaseBitmap(m_hBitmapHandle);
        m_hBitmapHandle = NULL;
    }
    if (m_buffer)
    {
        delete[] m_buffer;
        m_buffer = NULL;
    }
}

void wxImage::InitAlpha()
{
}
unsigned char* wxImage::GetData()
{
    return XL_GetBitmapBuffer(m_hBitmapHandle, 0, 0);
}
unsigned char* wxImage::GetAlpha()
{
    return NULL;
}
int wxImage::GetWidth()
{
    return m_width;
}
int wxImage::GetHeight()
{
    return m_height;
}
bool wxImage::HasAlpha()
{
    return false;
}
bool wxImage::Ok()
{
    return !!m_hBitmapHandle;
}
void wxImage::LoadFile(std::wstring& filename)
{
    m_hBitmapHandle = XL_LoadBitmapFromFile(filename.c_str(), XLGRAPHIC_CT_ARGB32);
    XLBitmapInfo info;
    XL_GetBitmapInfo(m_hBitmapHandle, &info);
    m_width = info.Width;
    m_height = info.Height;
}

XL_BITMAP_HANDLE wxImage::GetXLBitmapHandle()
{
    return m_hBitmapHandle;
}
