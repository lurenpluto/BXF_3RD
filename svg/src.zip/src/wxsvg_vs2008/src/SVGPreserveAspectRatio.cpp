//////////////////////////////////////////////////////////////////////////////
// Name:        SVGPreserveAspectRatio.cpp
// Purpose:     
// Author:      Alex Thuering
// Created:     2005/09/27
// RCS-ID:      $Id: SVGPreserveAspectRatio.cpp,v 1.2 2005/11/07 17:36:57 ntalex Exp $
// Copyright:   (c) 2005 Alex Thuering
// Licence:     wxWindows licence
//////////////////////////////////////////////////////////////////////////////

#include "SVGPreserveAspectRatio.h"
#include <wx/tokenzr.h>

std::wstring wxSVGPreserveAspectRatio::GetValueAsString() const
{
  std::wstring value;
  switch (m_align)
  {
    case wxSVG_PRESERVEASPECTRATIO_UNKNOWN: break;
    case wxSVG_PRESERVEASPECTRATIO_NONE:     value += _T("none"); break;
    case wxSVG_PRESERVEASPECTRATIO_XMINYMIN: value += _T("xminymin"); break;
    case wxSVG_PRESERVEASPECTRATIO_XMIDYMIN: value += _T("xmidymin"); break;
    case wxSVG_PRESERVEASPECTRATIO_XMAXYMIN: value += _T("xmaxymin"); break;
    case wxSVG_PRESERVEASPECTRATIO_XMINYMID: value += _T("xminymid"); break;
    case wxSVG_PRESERVEASPECTRATIO_XMIDYMID: value += _T("xmidymid"); break;
    case wxSVG_PRESERVEASPECTRATIO_XMAXYMID: value += _T("xmaxymid"); break;
    case wxSVG_PRESERVEASPECTRATIO_XMINYMAX: value += _T("xminymax"); break;
    case wxSVG_PRESERVEASPECTRATIO_XMIDYMAX: value += _T("xmidymax"); break;
    case wxSVG_PRESERVEASPECTRATIO_XMAXYMAX: value += _T("xmaxymax"); break;
  }
  
  if (value.length())
    value += _T(" ");
  
  switch (m_meetOrSlice)
  {
    case wxSVG_MEETORSLICE_UNKNOWN: break;
    case wxSVG_MEETORSLICE_MEET:  value += _T("meet"); break;
    case wxSVG_MEETORSLICE_SLICE: value += _T("slice"); break;
  }
    
  return value;
}

void wxSVGPreserveAspectRatio::SetValueAsString(const std::wstring& value)
{
  m_align = wxSVG_PRESERVEASPECTRATIO_UNKNOWN;
  m_meetOrSlice = wxSVG_MEETORSLICE_UNKNOWN;
  
  std::wstring valueLower = wxStringPort::Lower(wxStringPort::Strip(value, wxStringPort::both));
  std::wstring val = wxStringPort::BeforeFirst(valueLower, _T(' '));
  if (val == _T("defer"))
  {
      valueLower = wxStringPort::AfterFirst(valueLower, _T(' '));
      val = wxStringPort::BeforeFirst(valueLower, _T(' '));
  }
  if (!val.length())
    return;
  else if (val == _T("none"))
    m_align = wxSVG_PRESERVEASPECTRATIO_NONE;
  else if (val == _T("xminymin"))
    m_align = wxSVG_PRESERVEASPECTRATIO_XMINYMIN;
  else if (val == _T("xmidymin"))
    m_align = wxSVG_PRESERVEASPECTRATIO_XMIDYMIN;
  else if (val == _T("xmaxymin"))
    m_align = wxSVG_PRESERVEASPECTRATIO_XMAXYMIN;
  else if (val == _T("xminymid"))
    m_align = wxSVG_PRESERVEASPECTRATIO_XMINYMID;
  else if (val == _T("xmidymid"))
    m_align = wxSVG_PRESERVEASPECTRATIO_XMIDYMID;
  else if (val == _T("xmaxymid"))
    m_align = wxSVG_PRESERVEASPECTRATIO_XMAXYMID;
  else if (val == _T("xminymax"))
    m_align = wxSVG_PRESERVEASPECTRATIO_XMINYMAX;
  else if (val == _T("xmidymax"))
    m_align = wxSVG_PRESERVEASPECTRATIO_XMIDYMAX;
  else if (val == _T("xmaxymax"))
    m_align = wxSVG_PRESERVEASPECTRATIO_XMAXYMAX;
  valueLower = wxStringPort::AfterFirst(valueLower, _T(' '));
  val = wxStringPort::BeforeFirst(valueLower, _T(' '));
  if (val == _T("meet"))
    m_meetOrSlice = wxSVG_MEETORSLICE_MEET;
  else if (val == _T("slice"))
    m_meetOrSlice = wxSVG_MEETORSLICE_SLICE;
}
