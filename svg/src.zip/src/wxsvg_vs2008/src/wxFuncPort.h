#ifndef wxSVG_FUNCPORT_H
#define wxSVG_FUNCPORT_H

#include <Windows.h>
#include <string>
namespace wxFuncPort{

    bool wxFileExists (const std::wstring& filename);
}
#endif