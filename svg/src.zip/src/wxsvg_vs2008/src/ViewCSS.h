//////////////////////////////////////////////////////////////////////////////
// Name:        ViewCSS.h
// Purpose:     
// Author:      Alex Thuering
// Created:     2005/04/28
// RCS-ID:      $Id: ViewCSS.h,v 1.1.1.1 2005/05/10 17:51:20 ntalex Exp $
// Copyright:   (c) 2005 Alex Thuering
// Licence:     wxWindows licence
//////////////////////////////////////////////////////////////////////////////

#ifndef wxSVG_VIEW_CSS_H
#define wxSVG_VIEW_CSS_H

struct wxViewCSS {};

#endif //wxSVG_VIEW_CSS_H

