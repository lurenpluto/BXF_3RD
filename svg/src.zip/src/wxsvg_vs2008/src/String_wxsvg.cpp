#include "String_wxsvg.h"
#include "wx/defs.h"
#include <stdarg.h>
#include <errno.h>
namespace wxStringPort {

std::wstring Format(const wchar_t* pszFormat, ...)
{
    wchar_t buf[256] = {0};
    va_list ap;
    va_start(ap, pszFormat);
    swprintf(buf, sizeof(buf), pszFormat, ap);
    std::wstring out(buf);
    va_end(ap);
    return out;
}

bool ToLong(const std::wstring& str, long* var, int base)
{
    wchar_t* end;
    *var = wcstol(str.c_str(), &end, base);
    return !*end && (end != str.c_str());
}

bool ToDouble(const std::wstring& str, double* var)
{
    wchar_t* end;
    *var = wcstod(str.c_str(), &end);
    return !*end && (end != str.c_str());
}

inline int wxSafeIsspace(wchar_t ch) { return (ch < 127) && _istspace(ch); };

std::wstring& Trim(std::wstring& str, bool bFromRight)
{
    // first check if we're going to modify the string at all
    if ( !str.empty() &&
        (
        (bFromRight && wxSafeIsspace(str.at(str.length() - 1))) ||
        (!bFromRight && wxSafeIsspace(str.at(0u)))
        )
        )
    {
        if ( bFromRight )
        {
            // find last non-space character
            std::wstring::reverse_iterator psz = str.rbegin();
            while ( (psz != str.rend()) && wxSafeIsspace(*psz) )
                psz++;

            // truncate at trailing space start
            str.erase(psz.base(), str.end());
        }
        else
        {
            // find first non-space character
            std::wstring::iterator psz = str.begin();
            while ( (psz != str.end()) && wxSafeIsspace(*psz) )
                psz++;

            // fix up data and length
            str.erase(str.begin(), psz);
        }
    }

    return str;
}

std::wstring Strip(const std::wstring& str, wxStringPort::stripType w)
{
    std::wstring s = str;
    if ( w & wxStringPort::leading ) Trim(s, false);
    if ( w & wxStringPort::trailing ) Trim(s, true);
    return s;
}

std::wstring AfterLast(const std::wstring& str, wchar_t ch)
{
    std::wstring ret;
    int iPos = str.find_last_of(ch);
    if ( iPos == std::wstring::npos )
        ret = str;
    else
        ret = str.c_str() + iPos + 1;

    return ret;
}

std::wstring BeforeFirst(const std::wstring& str, wchar_t ch)
{
    int iPos = str.find(ch);
    if ( iPos == std::wstring::npos ) iPos = str.length();
    return std::wstring(str, 0, iPos);
}

std::wstring BeforeLast(const std::wstring& str, wchar_t ch)
{
    std::wstring ret;
    int iPos = str.find_last_of(ch);
    if ( iPos != std::wstring::npos && iPos != 0 )
        ret = std::wstring(str.c_str(), iPos);

    return ret;
}

std::wstring AfterFirst(const std::wstring& str, wchar_t ch)
{
    std::wstring ret;
    int iPos = str.find(ch);
    if ( iPos != std::wstring::npos )
        ret = str.c_str() + iPos + 1;

    return ret;
}

bool StartsWith(const std::wstring& str, const wchar_t *prefix, std::wstring *rest)
{
    if (!prefix)
    {
        return false;
    }

    const wchar_t *p = str.c_str();
    while ( *prefix )
    {
        if ( *prefix++ != *p++ )
        {
            // no match
            return false;
        }
    }

    if ( rest )
    {
        // put the rest of the string into provided pointer
        *rest = p;
    }

    return true;
}

bool EndsWith(const std::wstring& str, const wchar_t *suffix, std::wstring *rest)
{
    if (!suffix)
    {
        return false;
    }

    int start = str.length() - wcslen(suffix);
    if ( start < 0 || wcscmp(str.c_str() + start, suffix) != 0 )
        return false;

    if ( rest )
    {
        // put the rest of the string into provided pointer
        rest->assign(str, 0, start);
    }

    return true;
}

std::wstring& MakeLower(std::wstring& str)
{
    for ( std::wstring::iterator it = str.begin(); it != str.end(); ++it )
        *it = (wchar_t)_totlower(*it);

    return str;
}

std::wstring Lower(const std::wstring& str)
{
    std::wstring s(str); 
    return MakeLower(s);
}

std::wstring& MakeUpper(std::wstring& str)
{
    for ( std::wstring::iterator it = str.begin(); it != str.end(); ++it )
        *it = (wchar_t)_totupper(*it);

    return str;
}

std::wstring Upper(const std::wstring& str)
{
    std::wstring s(str); 
    return MakeUpper(s);
}

// replace first (or all) occurences of some substring with another one
size_t Replace(std::wstring& str, const wchar_t *szOld, const wchar_t *szNew, bool bReplaceAll)
{
    size_t uiCount = 0;   // count of replacements made

    const size_t uiOldLen = wcslen(szOld);
    const size_t uiNewLen = wcslen(szNew);

    for ( size_t pos = 0; ; )
    {
        pos = str.find(szOld, pos);
        if ( pos == std::wstring::npos )
            break;

        // replace this occurrence of the old string with the new one
        str.replace(pos, uiOldLen, szNew, uiNewLen);

        // move past the string that was replaced
        pos += uiNewLen;

        // increase replace count
        uiCount++;

        // stop now?
        if ( !bReplaceAll )
            break;
    }

    return uiCount;
}

}//namespace wxStringPort

int wxCMPFUNC_CONV wxStringSortAscending(std::wstring* s1, std::wstring* s2)
{
    return  wcscmp(s1->c_str(), s2->c_str());
}

int wxCMPFUNC_CONV wxStringSortDescending(std::wstring* s1, std::wstring* s2)
{
    return -wcscmp(s1->c_str(), s2->c_str());
}