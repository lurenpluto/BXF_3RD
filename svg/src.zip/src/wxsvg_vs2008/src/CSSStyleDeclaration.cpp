//////////////////////////////////////////////////////////////////////////////
// Name:        CSSStyleDeclaration.cpp
// Purpose:     
// Author:      Alex Thuering
// Created:     2005/05/03
// RCS-ID:      $Id: CSSStyleDeclaration.cpp,v 1.10 2010/03/28 11:38:05 ntalex Exp $
// Copyright:   (c) 2005 Alex Thuering
// Licence:     wxWindows licence
//////////////////////////////////////////////////////////////////////////////

#include "CSSStyleDeclaration.h"
#include <wx/tokenzr.h>

wxCSSPrimitiveValue* wxCSSStyleDeclaration::s_emptyCSSValue = new wxCSSPrimitiveValue;
wxSVGColor* wxCSSStyleDeclaration::s_emptySVGColor = new wxSVGColor;
wxSVGPaint* wxCSSStyleDeclaration::s_emptySVGPaint = new wxSVGPaint;
wxSVGPaint* wxCSSStyleDeclaration::s_blackSVGPaint = new wxSVGPaint(0,0,0);

wxCSSStyleDeclaration::~wxCSSStyleDeclaration()
{
  for (iterator it = begin(); it != end(); ++it)
	delete it->second;
}

wxCSSStyleDeclaration& wxCSSStyleDeclaration::operator=(const wxCSSStyleDeclaration& src)
{
  for (iterator it = begin(); it != end(); ++it)
	delete it->second;
  clear();
  Add(src);
  return *this;
}

void wxCSSStyleDeclaration::Add(const wxCSSStyleDeclaration& style)
{
  const_iterator it;
  for (it = style.begin(); it != style.end(); ++it) {
	iterator it2 = find(it->first);
	if (it2 != end()) { // replace old value with new one
		delete it2->second;
		it2->second = it->second->Clone();
	} else
		(*this)[it->first] = it->second->Clone();
  }
}

std::wstring wxCSSStyleDeclaration::GetCSSText() const
{
  std::wstring text;
  const_iterator it;
  for (it = begin(); it != end(); ++it) 
	text = text + GetPropertyName(it->first) + _T(":") + it->second->GetCSSText() + _T(";");
  return text;
}

void wxCSSStyleDeclaration::SetCSSText(const std::wstring& text)
{
  wxStringTokenizer tkz(text, _T(";"));
  while (tkz.HasMoreTokens()) 
  { 
    std::wstring token = wxStringPort::Strip(tkz.GetNextToken(), wxStringPort::both);
	int pos = token.find(_T(':'));
	if (pos<=0)
	  continue;
	SetProperty(token.substr(0,pos), token.substr(pos+1));
  }
}

static wxSortedArrayString* s_cssProperties = NULL;
#include "css_properties.cpp"
inline void FillCSSProperties()
{
  if (s_cssProperties == NULL)
  {
	s_cssProperties = new wxSortedArrayString;
	for (unsigned int i=0; i<sizeof(s_cssPropertyStrings)/sizeof(s_cssPropertyStrings[0]); i++)
	  s_cssProperties->Add(s_cssPropertyStrings[i]);
  }
}

wxCSS_PROPERTY wxCSSStyleDeclaration::GetPropertyId(const std::wstring& propertyName)
{
  FillCSSProperties();
  int id = s_cssProperties->Index(propertyName.c_str());
  if (id >= 0)
	return wxCSS_PROPERTY(id+1);
  return wxCSS_PROPERTY_UNKNOWN;
}

std::wstring wxCSSStyleDeclaration::GetPropertyName(wxCSS_PROPERTY propertyId)
{
  FillCSSProperties();
  if (propertyId == wxCSS_PROPERTY_UNKNOWN)
	return _T("");
  return (*s_cssProperties)[int(propertyId)-1];
}

void wxCSSStyleDeclaration::SetProperty(wxCSS_PROPERTY propertyId, const std::wstring& svalue)
{
  if (propertyId == wxCSS_PROPERTY_UNKNOWN)
    return;
  std::wstring value = wxStringPort::Strip(svalue, wxStringPort::both);
  wxCSSValue* cssValue = NULL;
  iterator it = find(propertyId);
  if (it != end())
    cssValue = it->second;
  if (value == _T("inherit")) {
  	if (cssValue != NULL)
  		erase(propertyId);
  	return;
  }
  switch (propertyId)
  {
    case wxCSS_PROPERTY_UNKNOWN:
      break;
    // only idents
    case wxCSS_PROPERTY_ALIGNMENT_BASELINE:
    case wxCSS_PROPERTY_BASELINE_SHIFT:
    case wxCSS_PROPERTY_CLIP_RULE:
    case wxCSS_PROPERTY_COLOR_INTERPOLATION:
    case wxCSS_PROPERTY_COLOR_INTERPOLATION_FILTERS:
    case wxCSS_PROPERTY_COLOR_RENDERING:
    case wxCSS_PROPERTY_DIRECTION:
    case wxCSS_PROPERTY_DISPLAY:
    case wxCSS_PROPERTY_DOMINANT_BASELINE:
    case wxCSS_PROPERTY_ENABLE_BACKGROUND:
    case wxCSS_PROPERTY_FILL_RULE:
    case wxCSS_PROPERTY_FONT_STRETCH:
    case wxCSS_PROPERTY_FONT_STYLE:
    case wxCSS_PROPERTY_FONT_VARIANT:
    case wxCSS_PROPERTY_FONT_WEIGHT:
    case wxCSS_PROPERTY_IMAGE_RENDERING:
    case wxCSS_PROPERTY_OVERFLOW:
    case wxCSS_PROPERTY_POINTER_EVENTS:
    case wxCSS_PROPERTY_SHAPE_RENDERING:
    case wxCSS_PROPERTY_STROKE_LINECAP:
    case wxCSS_PROPERTY_STROKE_LINEJOIN:
    case wxCSS_PROPERTY_TEXT_ANCHOR:
    case wxCSS_PROPERTY_TEXT_DECORATION:
    case wxCSS_PROPERTY_TEXT_RENDERING:
    case wxCSS_PROPERTY_UNICODE_BIDI:
    case wxCSS_PROPERTY_VISIBILITY:
    case wxCSS_PROPERTY_WRITING_MODE:
      if (!cssValue)
        cssValue = new wxCSSPrimitiveValue;
	  ((wxCSSPrimitiveValue*)cssValue)->SetIdentValue(wxCSSValue::GetValueId(value));
      break;
    case wxCSS_PROPERTY_CLIP:
      if (!cssValue)
        cssValue = new wxCSSPrimitiveValue;
	  if (value == _T("none"))
	  	((wxCSSPrimitiveValue*)cssValue)->SetIdentValue(wxCSS_VALUE_NONE);
	  else 
		((wxCSSPrimitiveValue*)cssValue)->SetStringValue(wxCSS_STRING, value);
      break;
    // url or ident
    case wxCSS_PROPERTY_CLIP_PATH:
    case wxCSS_PROPERTY_CURSOR:
    case wxCSS_PROPERTY_FILTER:
    case wxCSS_PROPERTY_MARKER_END:
    case wxCSS_PROPERTY_MARKER_MID:
    case wxCSS_PROPERTY_MARKER_START:
    case wxCSS_PROPERTY_MASK:
      if (!cssValue)
        cssValue = new wxCSSPrimitiveValue;
	  if (value.substr(0, 3) == _T("url"))
		((wxCSSPrimitiveValue*)cssValue)->SetStringValue(wxCSS_URI,
        wxStringPort::BeforeFirst(wxStringPort::AfterFirst(value, _T('(')), _T(')')));
	  else
		((wxCSSPrimitiveValue*)cssValue)->SetIdentValue(wxCSSValue::GetValueId(value));
      break;
    case wxCSS_PROPERTY_COLOR:
      if (!cssValue)
        cssValue = new wxCSSPrimitiveValue;
	  ((wxCSSPrimitiveValue*)cssValue)->SetRGBColorValue(ParseColor(value));
      break;
    case wxCSS_PROPERTY_COLOR_PROFILE:
      if (!cssValue)
        cssValue = new wxCSSPrimitiveValue;
      if (value == _T("auto"))
      	((wxCSSPrimitiveValue*)cssValue)->SetIdentValue(wxCSS_VALUE_AUTO);
      else if (value == _T("sRGB"))
      	((wxCSSPrimitiveValue*)cssValue)->SetIdentValue(wxCSS_VALUE_SRGB);
	  else if (value.substr(0, 3) == _T("url"))
		((wxCSSPrimitiveValue*)cssValue)->SetStringValue(wxCSS_URI,
		  wxStringPort::BeforeFirst(wxStringPort::AfterFirst(value, _T('(')), _T(')')));
	  else
		((wxCSSPrimitiveValue*)cssValue)->SetStringValue(wxCSS_STRING, value);
      break;
    // number
    case wxCSS_PROPERTY_FILL_OPACITY:
    case wxCSS_PROPERTY_FLOOD_OPACITY:
    case wxCSS_PROPERTY_FONT_SIZE:
    case wxCSS_PROPERTY_GLYPH_ORIENTATION_HORIZONTAL:
    case wxCSS_PROPERTY_STROKE_DASHOFFSET:
    case wxCSS_PROPERTY_STROKE_MITERLIMIT:
    case wxCSS_PROPERTY_STROKE_OPACITY:
    case wxCSS_PROPERTY_STROKE_WIDTH:
    case wxCSS_PROPERTY_OPACITY:
    case wxCSS_PROPERTY_STOP_OPACITY:
      if (!cssValue)
        cssValue = new wxCSSPrimitiveValue;
	  ((wxCSSPrimitiveValue*)cssValue)->SetFloatValue(wxCSS_NUMBER, ParseNumber(value));
      break;
    // 'none' or number
    case wxCSS_PROPERTY_FONT_SIZE_ADJUST:
      if (!cssValue)
        cssValue = new wxCSSPrimitiveValue;
	  if (value == _T("none"))
	  	((wxCSSPrimitiveValue*)cssValue)->SetIdentValue(wxCSS_VALUE_NONE);
	  else 
		((wxCSSPrimitiveValue*)cssValue)->SetFloatValue(wxCSS_NUMBER, ParseNumber(value));
      break;
    // 'auto' or number
    case wxCSS_PROPERTY_GLYPH_ORIENTATION_VERTICAL:
    case wxCSS_PROPERTY_KERNING:
    case wxCSS_PROPERTY_LETTER_SPACING:
      if (!cssValue)
        cssValue = new wxCSSPrimitiveValue;
	  if (value == _T("auto"))
	  	((wxCSSPrimitiveValue*)cssValue)->SetIdentValue(wxCSS_VALUE_AUTO);
	  else 
		((wxCSSPrimitiveValue*)cssValue)->SetFloatValue(wxCSS_NUMBER, ParseNumber(value));
      break;
    // 'normal' or number
    case wxCSS_PROPERTY_WORD_SPACING:
      if (!cssValue)
        cssValue = new wxCSSPrimitiveValue;
	  if (value == _T("normal"))
	  	((wxCSSPrimitiveValue*)cssValue)->SetIdentValue(wxCSS_VALUE_AUTO);
	  else 
		((wxCSSPrimitiveValue*)cssValue)->SetFloatValue(wxCSS_NUMBER, ParseNumber(value));
      break;
    // string
    case wxCSS_PROPERTY_FONT_FAMILY:
    case wxCSS_PROPERTY_STROKE_DASHARRAY:
      if (!cssValue)
        cssValue = new wxCSSPrimitiveValue;
      ((wxCSSPrimitiveValue*)cssValue)->SetStringValue(wxCSS_STRING, value);
      break;
    // <color>
    case wxCSS_PROPERTY_FLOOD_COLOR:
    case wxCSS_PROPERTY_LIGHTING_COLOR:
    case wxCSS_PROPERTY_STOP_COLOR:
      if (!cssValue)
        cssValue = new wxSVGColor;
	  ((wxSVGColor*)cssValue)->SetRGBColor(ParseColor(value));
      break;
    // <paint>
    case wxCSS_PROPERTY_FILL:
    case wxCSS_PROPERTY_STROKE:
      if (!cssValue)
        cssValue = new wxSVGPaint;
	  ParseSVGPaint(*(wxSVGPaint*)cssValue, value);
      break;
  }
  if (it == end())
    (*this)[propertyId] = cssValue;
}

double wxCSSStyleDeclaration::ParseNumber(const std::wstring& value)
{
  double val = 0;
  wxStringPort::ToDouble(value, &val);
  return val;
}

static wxSortedArrayString* s_cssColors = NULL;
#include "css_colors.cpp"
inline void FillCSSColors()
{
  if (s_cssColors == NULL)
  {
	s_cssColors = new wxSortedArrayString;
	for (unsigned int i=0; i<sizeof(s_cssNamedColors)/sizeof(s_cssNamedColors[0]); i++)
	  s_cssColors->Add(s_cssNamedColors[i].name);
  }
}

wxRGBColor wxCSSStyleDeclaration::ParseColor(const std::wstring& value)
{
  if (!value.length() || value == _T("none"))
	return wxRGBColor();
  else if (value.at(0) == _T('#'))
  {
      long r = 0, g = 0, b = 0;
      if (value.length() == 4) //#abc
      {
          std::wstring rr = value.substr(1,1);
          rr.append(rr);
          std::wstring gg = value.substr(2,1);
          gg.append(gg);
          std::wstring bb = value.substr(3,1);
          bb.append(bb);

          wxStringPort::ToLong(rr, &r,16);
          wxStringPort::ToLong(gg, &g,16);
          wxStringPort::ToLong(bb, &b,16);
      }
      else //#abcdef
      {
          
          wxStringPort::ToLong(value.substr(1,2), &r,16);
          wxStringPort::ToLong(value.substr(3,2), &g,16);
          wxStringPort::ToLong(value.substr(5,2), &b,16);
      }
      return wxRGBColor(r,g,b);
  }
  else if (value.substr(0, 3) == _T("rgb"))
  {
	wxStringTokenizer tkz(value.substr(3), _T(",()"));
	long rgb[3] = { 0, 0, 0 };
	for (int i=0; tkz.HasMoreTokens() && i<3;)
	{
        std::wstring token = wxStringPort::Strip(tkz.GetNextToken(), wxStringPort::both);
	  if (token.length())
          wxStringPort::ToLong(token, &rgb[i++]);
	}
	return wxRGBColor(rgb[0], rgb[1], rgb[2]);
  }
  else
  {
	FillCSSColors();
	int num = s_cssColors->Index(value.c_str());
	if (num>=0)
	  return s_cssNamedColors[num].colour;
  }
  return wxRGBColor();
}

void wxCSSStyleDeclaration::ParseSVGPaint(wxSVGPaint& cssValue, const std::wstring& value)
{
  std::wstring val = value;
  if (val.substr(0, 3) == _T("url"))
  {
	//cssValue.SetUri(value.AfterFirst(_T('(')).BeforeFirst(_T(')')));
    cssValue.SetUri(wxStringPort::BeforeFirst(wxStringPort::AfterFirst(value, _T('(')), _T(')')));
	//val = value.AfterFirst(_T(')')).Strip(wxStringPort::both);
    val = wxStringPort::Strip(wxStringPort::AfterFirst(value, _T(')')), wxStringPort::both);
  }
  cssValue.SetRGBColor(ParseColor(val));
}

//////////////////////////////////////////////////////////////////////////////
///////////////////////// wxCSSStyleRef //////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////
wxCSSStyleRef::~wxCSSStyleRef()
{
  while (size())
	erase(begin());
}

void wxCSSStyleRef::Add(const wxCSSStyleDeclaration& style)
{
  const_iterator it;
  for (it = style.begin(); it != style.end(); ++it)
	(*this)[it->first] = it->second;
}

