/////////////////////////////////////////////////////////////////////////////
// Name:        src/common/colourcmn.cpp
// Purpose:     wxColourBase implementation
// Author:      Francesco Montorsi
// Modified by:
// Created:     20/4/2006
// RCS-ID:      $Id: colourcmn.cpp 41538 2006-09-30 20:45:15Z RR $
// Copyright:   (c) Francesco Montorsi
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////


// For compilers that support precompilation, includes "wx.h".

#include "wx/colour.h"

#ifndef WX_PRECOMP
    #include "wx/gdicmn.h"
#endif
#include "wx/geometry.h"
#include <stdio.h>

// ============================================================================
// wxString <-> wxColour conversions
// ============================================================================

bool wxColourBase::FromString(const wchar_t *str)
{
    if ( str == NULL || str[0] == _T('\0'))
        return false;       // invalid or empty string

    if ( wcsncmp(str, _T("RGB"), 3) == 0 ||
         wcsncmp(str, _T("rgb"), 3) == 0 )
    {
        // CSS-like RGB specification
        // according to http://www.w3.org/TR/REC-CSS2/syndata.html#color-units
        // values outside 0-255 range are allowed but should be clipped
        int red, green, blue;
        if (swscanf(&str[3], _T("(%d, %d, %d)"), &red, &green, &blue) != 3)
            return false;

        Set((unsigned char)wxClip(red,0,255),
            (unsigned char)wxClip(green,0,255),
            (unsigned char)wxClip(blue,0,255));
    }
    else if ( str[0] == _T('#') && wcslen(str) == 7 )
    {
        // hexadecimal prefixed with # (HTML syntax)
        unsigned long tmp;
        if (swscanf(&str[1], _T("%lx"), &tmp) != 1)
            return false;

        Set((unsigned char)(tmp >> 16),
            (unsigned char)(tmp >> 8),
            (unsigned char)tmp);
    }
    else if (wxTheColourDatabase) // a colour name ?
    {
        // we can't do
        // *this = wxTheColourDatabase->Find(str)
        // because this place can be called from constructor
        // and 'this' could not be available yet
        wxColour clr = wxTheColourDatabase->Find(str);
        if (clr.Ok())
            Set((unsigned char)clr.Red(),
                (unsigned char)clr.Green(),
                (unsigned char)clr.Blue());
    }

    if (Ok())
        return true;
    return false;
}