///////////////////////////////////////////////////////////////////////////////
// Name:        src/common/appbase.cpp
// Purpose:     implements wxAppConsole class
// Author:      Vadim Zeitlin
// Modified by:
// Created:     19.06.2003 (extracted from common/appcmn.cpp)
// RCS-ID:      $Id: appbase.cpp 52093 2008-02-25 13:43:07Z VZ $
// Copyright:   (c) 2003 Vadim Zeitlin <vadim@wxwindows.org>
// License:     wxWindows license
///////////////////////////////////////////////////////////////////////////////

// ============================================================================
// declarations
// ============================================================================

// ----------------------------------------------------------------------------
// headers
// ----------------------------------------------------------------------------

// for compilers that support precompilation, includes "wx.h".

#include  "wx/msw/wrapwin.h"  // includes windows.h for MessageBox()

#include "wx/tokenzr.h"

#if !defined(__WXMSW__) || defined(__WXMICROWIN__)
  #include  <signal.h>      // for SIGTRAP used by wxTrap()
#endif  //Win/Unix

// ----------------------------------------------------------------------------
// private functions prototypes
// ----------------------------------------------------------------------------

#ifdef __WXDEBUG__
    // really just show the assert dialog
static bool DoShowAssertDialog(const std::wstring& msg);

    // prepare for showing the assert dialog, use the given traits or
    // DoShowAssertDialog() as last fallback to really show it
    static
    void ShowAssertDialog(const wchar_t *szFile,
                          int nLine,
                          const wchar_t *szFunc,
                          const wchar_t *szCond,
                          const wchar_t *szMsg);

    // turn on the trace masks specified in the env variable WXTRACE
    static void LINKAGEMODE SetTraceMasks();
#endif // __WXDEBUG__

// ----------------------------------------------------------------------------
// global vars
// ----------------------------------------------------------------------------

// ============================================================================
// global functions implementation
// ============================================================================

#ifdef  __WXDEBUG__

// wxASSERT() helper
bool wxAssertIsEqual(int x, int y)
{
    return x == y;
}

// break into the debugger
void wxTrap()
{
    DebugBreak();
}

// this function is called when an assert fails
void wxOnAssert(const wchar_t *szFile,
                int nLine,
                const char *szFunc,
                const wchar_t *szCond,
                const wchar_t *szMsg)
{
    // __FUNCTION__ is always in ASCII, convert it to wide char if needed
    //const std::wstring strFunc = wxString::FromAscii(szFunc);

    ShowAssertDialog(szFile, nLine, _T(""), szCond, szMsg);
}

#endif // __WXDEBUG__

// ============================================================================
// private functions implementation
// ============================================================================

#ifdef __WXDEBUG__

static void LINKAGEMODE SetTraceMasks()
{

}

bool DoShowAssertDialog(const std::wstring& msg)
{
    // under MSW we can show the dialog even in the console mode
#if defined(__WXMSW__) && !defined(__WXMICROWIN__)
    std::wstring msgDlg(msg);

    // this message is intentionally not translated -- it is for
    // developpers only
    msgDlg += _T("\nDo you want to stop the program?\n")
              _T("You can also choose [Cancel] to suppress ")
              _T("further warnings.");

    switch ( ::MessageBox(NULL, msgDlg.c_str(), _T("wxWidgets Debug Alert"),
                          MB_YESNOCANCEL | MB_ICONSTOP ) )
    {
        case IDYES:
            wxTrap();
            break;

        case IDCANCEL:
            // stop the asserts
            return true;

        //case IDNO: nothing to do
    }
#else // !__WXMSW__
    wxFprintf(stderr, wxT("%s\n"), msg.c_str());
    fflush(stderr);

    // TODO: ask the user to enter "Y" or "N" on the console?
    wxTrap();
#endif // __WXMSW__/!__WXMSW__

    // continue with the asserts
    return false;
}

// show the assert modal dialog
static
void ShowAssertDialog(const wchar_t *szFile,
                      int nLine,
                      const wchar_t *szFunc,
                      const wchar_t *szCond,
                      const wchar_t *szMsg)
{
    // this variable can be set to true to suppress "assert failure" messages
    static bool s_bNoAsserts = false;

    std::wstring msg;
    msg.reserve(2048);

    wchar_t msgbuf[2048] = {0};

    // make life easier for people using VC++ IDE by using this format: like
    // this, clicking on the message will take us immediately to the place of
    // the failed assert

    swprintf(msgbuf, sizeof(msgbuf), _T("%s(%d): assert \"%s\" failed"), szFile, nLine, szCond);
    
    msg.assign(msgbuf);

    // add the function name, if any
    if ( szFunc && *szFunc )
    {
        msg.append(_T(" in "));
        msg.append(szFunc);
        msg.append(_T("()"));
    }

    // and the message itself
    if ( szMsg )
    {
        msg.append(_T(": "));
        msg.append(szMsg);
    }
    else // no message given
    {
        msg.append(_T("."));
    }

    if ( !s_bNoAsserts )
    {
        // fall back to the function of last resort
        s_bNoAsserts = DoShowAssertDialog(msg);
    }
}

#endif // __WXDEBUG__
