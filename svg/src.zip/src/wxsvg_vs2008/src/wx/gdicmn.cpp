/////////////////////////////////////////////////////////////////////////////
// Name:        src/common/gdicmn.cpp
// Purpose:     Common GDI classes
// Author:      Julian Smart
// Modified by:
// Created:     01/02/97
// RCS-ID:      $Id: gdicmn.cpp 50022 2007-11-17 14:24:18Z VZ $
// Copyright:   (c) Julian Smart
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

// For compilers that support precompilation, includes "wx.h".

#include "wx/gdicmn.h"

#ifndef WX_PRECOMP
    #include "wx/colour.h"
    #include "wx/geometry.h"
#endif

wxColourDatabase* wxTheColourDatabase;
wxColour  wxNullColour;

const wxSize wxDefaultSize(wxDefaultCoord, wxDefaultCoord);
const wxPoint wxDefaultPosition(wxDefaultCoord, wxDefaultCoord);

wxRect::wxRect(const wxPoint& point1, const wxPoint& point2)
{
    x = point1.x;
    y = point1.y;
    width = point2.x - point1.x;
    height = point2.y - point1.y;

    if (width < 0)
    {
        width = -width;
        x = point2.x;
    }
    width++;

    if (height < 0)
    {
        height = -height;
        y = point2.y;
    }
    height++;
}

bool wxRect::operator==(const wxRect& rect) const
{
    return ((x == rect.x) &&
            (y == rect.y) &&
            (width == rect.width) &&
            (height == rect.height));
}

wxRect wxRect::operator+(const wxRect& rect) const
{
    int x1 = wxMin(this->x, rect.x);
    int y1 = wxMin(this->y, rect.y);
    int y2 = wxMax(y+height, rect.height+rect.y);
    int x2 = wxMax(x+width, rect.width+rect.x);
    return wxRect(x1, y1, x2-x1, y2-y1);
}

wxRect& wxRect::Union(const wxRect& rect)
{
    // ignore empty rectangles: union with an empty rectangle shouldn't extend
    // this one to (0, 0)
    if ( !width || !height )
    {
        *this = rect;
    }
    else if ( rect.width && rect.height )
    {
        int x1 = wxMin(x, rect.x);
        int y1 = wxMin(y, rect.y);
        int y2 = wxMax(y + height, rect.height + rect.y);
        int x2 = wxMax(x + width, rect.width + rect.x);

        x = x1;
        y = y1;
        width = x2 - x1;
        height = y2 - y1;
    }
    //else: we're not empty and rect is empty

    return *this;
}

wxRect& wxRect::Inflate(wxCoord dx, wxCoord dy)
{
     if (-2*dx>width)
     {
         // Don't allow deflate to eat more width than we have,
         // a well-defined rectangle cannot have negative width.
         x+=width/2;
         width=0;
     }
     else
     {
         // The inflate is valid.
         x-=dx;
         width+=2*dx;
     }

     if (-2*dy>height)
     {
         // Don't allow deflate to eat more height than we have,
         // a well-defined rectangle cannot have negative height.
         y+=height/2;
         height=0;
     }
     else
     {
         // The inflate is valid.
         y-=dy;
         height+=2*dy;
     }

    return *this;
}

bool wxRect::Contains(int cx, int cy) const
{
    return ( (cx >= x) && (cy >= y)
          && ((cy - y) < height)
          && ((cx - x) < width)
          );
}

bool wxRect::Contains(const wxRect& rect) const
{
    return Contains(rect.GetTopLeft()) && Contains(rect.GetBottomRight());
}

wxRect& wxRect::Intersect(const wxRect& rect)
{
    int x2 = GetRight(),
        y2 = GetBottom();

    if ( x < rect.x )
        x = rect.x;
    if ( y < rect.y )
        y = rect.y;
    if ( x2 > rect.GetRight() )
        x2 = rect.GetRight();
    if ( y2 > rect.GetBottom() )
        y2 = rect.GetBottom();

    width = x2 - x + 1;
    height = y2 - y + 1;

    if ( width <= 0 || height <= 0 )
    {
        width =
        height = 0;
    }

    return *this;
}

bool wxRect::Intersects(const wxRect& rect) const
{
    wxRect r = Intersect(rect);

    // if there is no intersection, both width and height are 0
    return r.width != 0;
}

// ============================================================================
// wxColourDatabase
// ============================================================================

// ----------------------------------------------------------------------------
// wxColourDatabase ctor/dtor
// ----------------------------------------------------------------------------

wxColourDatabase::wxColourDatabase ()
{
    // will be created on demand in Initialize()
    m_map = NULL;
}

wxColourDatabase::~wxColourDatabase ()
{
    if ( m_map )
    {
        WX_CLEAR_HASH_MAP(wxStringToColourHashMap, *m_map);

        delete m_map;
    }
}

// Colour database stuff
void wxColourDatabase::Initialize()
{
    if ( m_map )
    {
        // already initialized
        return;
    }

    m_map = new wxStringToColourHashMap;

    static const struct wxColourDesc
    {
        const wchar_t *name;
        unsigned char r,g,b;
    }
    wxColourTable[] =
    {
        {_T("AQUAMARINE"),112, 219, 147},
        {_T("BLACK"),0, 0, 0},
        {_T("BLUE"), 0, 0, 255},
        {_T("BLUE VIOLET"), 159, 95, 159},
        {_T("BROWN"), 165, 42, 42},
        {_T("CADET BLUE"), 95, 159, 159},
        {_T("CORAL"), 255, 127, 0},
        {_T("CORNFLOWER BLUE"), 66, 66, 111},
        {_T("CYAN"), 0, 255, 255},
        {_T("DARK GREY"), 47, 47, 47},   // ?

        {_T("DARK GREEN"), 47, 79, 47},
        {_T("DARK OLIVE GREEN"), 79, 79, 47},
        {_T("DARK ORCHID"), 153, 50, 204},
        {_T("DARK SLATE BLUE"), 107, 35, 142},
        {_T("DARK SLATE GREY"), 47, 79, 79},
        {_T("DARK TURQUOISE"), 112, 147, 219},
        {_T("DIM GREY"), 84, 84, 84},
        {_T("FIREBRICK"), 142, 35, 35},
        {_T("FOREST GREEN"), 35, 142, 35},
        {_T("GOLD"), 204, 127, 50},
        {_T("GOLDENROD"), 219, 219, 112},
        {_T("GREY"), 128, 128, 128},
        {_T("GREEN"), 0, 255, 0},
        {_T("GREEN YELLOW"), 147, 219, 112},
        {_T("INDIAN RED"), 79, 47, 47},
        {_T("KHAKI"), 159, 159, 95},
        {_T("LIGHT BLUE"), 191, 216, 216},
        {_T("LIGHT GREY"), 192, 192, 192},
        {_T("LIGHT STEEL BLUE"), 143, 143, 188},
        {_T("LIME GREEN"), 50, 204, 50},
        {_T("LIGHT MAGENTA"), 255, 0, 255},
        {_T("MAGENTA"), 255, 0, 255},
        {_T("MAROON"), 142, 35, 107},
        {_T("MEDIUM AQUAMARINE"), 50, 204, 153},
        {_T("MEDIUM GREY"), 100, 100, 100},
        {_T("MEDIUM BLUE"), 50, 50, 204},
        {_T("MEDIUM FOREST GREEN"), 107, 142, 35},
        {_T("MEDIUM GOLDENROD"), 234, 234, 173},
        {_T("MEDIUM ORCHID"), 147, 112, 219},
        {_T("MEDIUM SEA GREEN"), 66, 111, 66},
        {_T("MEDIUM SLATE BLUE"), 127, 0, 255},
        {_T("MEDIUM SPRING GREEN"), 127, 255, 0},
        {_T("MEDIUM TURQUOISE"), 112, 219, 219},
        {_T("MEDIUM VIOLET RED"), 219, 112, 147},
        {_T("MIDNIGHT BLUE"), 47, 47, 79},
        {_T("NAVY"), 35, 35, 142},
        {_T("ORANGE"), 204, 50, 50},
        {_T("ORANGE RED"), 255, 0, 127},
        {_T("ORCHID"), 219, 112, 219},
        {_T("PALE GREEN"), 143, 188, 143},
        {_T("PINK"), 255, 192, 203},
        {_T("PLUM"), 234, 173, 234},
        {_T("PURPLE"), 176, 0, 255},
        {_T("RED"), 255, 0, 0},
        {_T("SALMON"), 111, 66, 66},
        {_T("SEA GREEN"), 35, 142, 107},
        {_T("SIENNA"), 142, 107, 35},
        {_T("SKY BLUE"), 50, 153, 204},
        {_T("SLATE BLUE"), 0, 127, 255},
        {_T("SPRING GREEN"), 0, 255, 127},
        {_T("STEEL BLUE"), 35, 107, 142},
        {_T("TAN"), 219, 147, 112},
        {_T("THISTLE"), 216, 191, 216},
        {_T("TURQUOISE"), 173, 234, 234},
        {_T("VIOLET"), 79, 47, 79},
        {_T("VIOLET RED"), 204, 50, 153},
        {_T("WHEAT"), 216, 216, 191},
        {_T("WHITE"), 255, 255, 255},
        {_T("YELLOW"), 255, 255, 0},
        {_T("YELLOW GREEN"), 153, 204, 50}
    };

    size_t n;

    for ( n = 0; n < WXSIZEOF(wxColourTable); n++ )
    {
        const wxColourDesc& cc = wxColourTable[n];
        (*m_map)[cc.name] = new wxColour(cc.r, cc.g, cc.b);
    }
}

// ----------------------------------------------------------------------------
// wxColourDatabase operations
// ----------------------------------------------------------------------------

void wxColourDatabase::AddColour(const std::wstring& name, const wxColour& colour)
{
    Initialize();

    // canonicalize the colour names before using them as keys: they should be
    // in upper case
    std::wstring colName = name;
    wxStringPort::MakeUpper(colName);

    // ... and we also allow both grey/gray
    std::wstring colNameAlt = colName;
    if ( !wxStringPort::Replace(colNameAlt, _T("GRAY"), _T("GREY")) )
    {
        // but in this case it is not necessary so avoid extra search below
        colNameAlt.clear();
    }

    wxStringToColourHashMap::iterator it = m_map->find(colName);
    if ( it == m_map->end() && !colNameAlt.empty() )
        it = m_map->find(colNameAlt);
    if ( it != m_map->end() )
    {
        *(it->second) = colour;
    }
    else // new colour
    {
        (*m_map)[colName] = new wxColour(colour);
    }
}

wxColour wxColourDatabase::Find(const std::wstring& colour) const
{
    wxColourDatabase * const self = wxConstCast(this, wxColourDatabase);
    self->Initialize();

    // make the comparaison case insensitive and also match both grey and gray
    std::wstring colName = colour;
    wxStringPort::MakeUpper(colName);
    std::wstring colNameAlt = colName;
    if ( !wxStringPort::Replace(colNameAlt, _T("GRAY"), _T("GREY")) )
        colNameAlt.clear();

    wxStringToColourHashMap::iterator it = m_map->find(colName);
    if ( it == m_map->end() && !colNameAlt.empty() )
        it = m_map->find(colNameAlt);
    if ( it != m_map->end() )
        return *(it->second);

    // we did not find any result in existing colours:
    // we won't use wxString -> wxColour conversion because the
    // wxColour::Set(const wxString &) function which does that conversion
    // internally uses this function (wxColourDatabase::Find) and we want
    // to avoid infinite recursion !
    return wxNullColour;
}

std::wstring wxColourDatabase::FindName(const wxColour& colour) const
{
    wxColourDatabase * const self = wxConstCast(this, wxColourDatabase);
    self->Initialize();

    typedef wxStringToColourHashMap::iterator iterator;

    for ( iterator it = m_map->begin(), en = m_map->end(); it != en; ++it )
    {
        if ( *(it->second) == colour )
            return it->first;
    }

    return _T("");
}