/////////////////////////////////////////////////////////////////////////////
// Name:        xml.cpp
// Purpose:     wxSvgXmlDocument - XML parser & data holder class
// Author:      Vaclav Slavik
// Created:     2000/03/05
// RCS-ID:      $Id: svgxml.cpp,v 1.7 2012/04/09 12:20:07 ntalex Exp $
// Copyright:   (c) 2000 Vaclav Slavik
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#if defined(__GNUG__) && !defined(NO_GCC_PRAGMA)
#pragma implementation "svgxml.h"
#endif

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#include "svgxml.h"
#include <wx/debug.h>

#include <expat/expat.h>

#include "wxFuncPort.h"

struct wxSvgXmlParsingContext
{
    wxSvgXmlDocument* doc;
    wxSvgXmlNode *root;
    wxSvgXmlNode *node;
    wxSvgXmlNode *lastAsText;
    std::wstring   encoding;
    std::wstring   version;
};

//-----------------------------------------------------------------------------
//  wxSvgXmlNode
//-----------------------------------------------------------------------------

wxSvgXmlNode::wxSvgXmlNode(wxSvgXmlNode *parent,wxSvgXmlNodeType type,
                     const std::wstring& name, const std::wstring& content,
                     wxSvgXmlProperty *props, wxSvgXmlNode *next)
    : m_type(type), m_name(name), m_content(content),
      m_properties(props), m_parent(parent),
      m_children(NULL), m_next(next), m_ownerDocument(NULL)
{
    if (m_parent)
    {
        if (m_parent->m_children)
        {
            m_next = m_parent->m_children;
            m_parent->m_children = this;
        }
        else
            m_parent->m_children = this;
    }
}

wxSvgXmlNode::wxSvgXmlNode(wxSvgXmlNodeType type, const std::wstring& name,
                     const std::wstring& content)
    : m_type(type), m_name(name), m_content(content),
      m_properties(NULL), m_parent(NULL),
      m_children(NULL), m_next(NULL)
{}

wxSvgXmlNode::wxSvgXmlNode(const wxSvgXmlNode& node)
{
    m_next = NULL;
    m_parent = NULL;
    DoCopy(node);
}

wxSvgXmlNode::~wxSvgXmlNode()
{
    wxSvgXmlNode *c, *c2;
    for (c = m_children; c; c = c2)
    {
        c2 = c->m_next;
        delete c;
    }

    wxSvgXmlProperty *p, *p2;
    for (p = m_properties; p; p = p2)
    {
        p2 = p->GetNext();
        delete p;
    }
}

wxSvgXmlNode& wxSvgXmlNode::operator=(const wxSvgXmlNode& node)
{
    wxDELETE(m_properties);
    wxDELETE(m_children);
    DoCopy(node);
    return *this;
}

void wxSvgXmlNode::DoCopy(const wxSvgXmlNode& node)
{
    m_type = node.m_type;
    m_name = node.m_name;
    m_content = node.m_content;
    m_children = NULL;

    wxSvgXmlNode *n = node.m_children;
    while (n)
    {
        AddChild(n->CloneNode());
        n = n->GetNext();
    }

    m_properties = NULL;
    wxSvgXmlProperty *p = node.m_properties;
    while (p)
    {
       AddProperty(p->GetName(), p->GetValue());
       p = p->GetNext();
    }
}

void wxSvgXmlNode::SetOwnerDocument(wxSvgXmlDocument* ownerDocument)
{
    m_ownerDocument = ownerDocument;
    wxSvgXmlNode *child = GetChildren();
    while (child)
    {
        child->SetOwnerDocument(ownerDocument);
        child = child->GetNext();
    }
}

bool wxSvgXmlNode::HasProp(const std::wstring& propName) const
{
    wxSvgXmlProperty *prop = GetProperties();

    while (prop)
    {
        if (prop->GetName() == propName) return TRUE;
        prop = prop->GetNext();
    }

    return FALSE;
}

bool wxSvgXmlNode::GetPropVal(const std::wstring& propName, std::wstring *value) const
{
    wxSvgXmlProperty *prop = GetProperties();

    while (prop)
    {
        if (prop->GetName() == propName)
        {
            *value = prop->GetValue();
            return TRUE;
        }
        prop = prop->GetNext();
    }

    return FALSE;
}

std::wstring wxSvgXmlNode::GetPropVal(const std::wstring& propName, const std::wstring& defaultVal) const
{
    std::wstring tmp;
    if (GetPropVal(propName, &tmp))
        return tmp;

    return defaultVal;
}

void wxSvgXmlNode::AddChild(wxSvgXmlNode *child)
{
    if (m_children == NULL)
        m_children = child;
    else
    {
        wxSvgXmlNode *ch = m_children;
        while (ch->m_next) ch = ch->m_next;
        ch->m_next = child;
    }
    child->m_next = NULL;
    child->m_parent = this;
    child->SetOwnerDocument(m_ownerDocument);
}

void wxSvgXmlNode::InsertChild(wxSvgXmlNode *child, wxSvgXmlNode *before_node)
{
    wxASSERT_MSG(before_node == NULL || before_node->GetParent() == this,
    		_T("wxSvgXmlNode::InsertChild - the node has incorrect parent"));

    if (m_children == before_node)
       m_children = child;
    else
    {
        wxSvgXmlNode *ch = m_children;
        while (ch->m_next != before_node) ch = ch->m_next;
        ch->m_next = child;
    }

    child->m_parent = this;
    child->m_next = before_node;
    child->SetOwnerDocument(m_ownerDocument);
}

bool wxSvgXmlNode::RemoveChild(wxSvgXmlNode *child)
{
    if (m_children == NULL)
        return FALSE;
    else if (m_children == child)
    {
        m_children = child->m_next;
        child->m_parent = NULL;
        child->m_next = NULL;
        return TRUE;
    }
    else
    {
        wxSvgXmlNode *ch = m_children;
        while (ch->m_next)
        {
            if (ch->m_next == child)
            {
                ch->m_next = child->m_next;
                child->m_parent = NULL;
                child->m_next = NULL;
                return TRUE;
            }
            ch = ch->m_next;
        }
        return FALSE;
    }
}

wxSvgXmlNode* wxSvgXmlNode::GetLastChild() const
{
    wxSvgXmlNode* child = m_children;
    if (child)
    {
        while (child->m_next)
            child = child->m_next;
    }
    return child;
}

wxSvgXmlNode* wxSvgXmlNode::GetPreviousSibling() const
{
    if (!m_parent)
        return NULL;
    wxSvgXmlNode* node = m_parent->m_children;
    if (node == this || node == NULL)
        return NULL;
    while (node->m_next)
    {
        if (node->m_next == this)
          return node;
        node = node->m_next;
    }
    return NULL;
}

void wxSvgXmlNode::AddProperty(const std::wstring& name, const std::wstring& value)
{
    AddProperty(new wxSvgXmlProperty(name, value, NULL));
}

void wxSvgXmlNode::AddProperty(wxSvgXmlProperty *prop)
{
    if (m_properties == NULL)
        m_properties = prop;
    else
    {
        wxSvgXmlProperty *p = m_properties;
        while (p->GetNext()) p = p->GetNext();
        p->SetNext(prop);
    }
}

bool wxSvgXmlNode::DeleteProperty(const std::wstring& name)
{
    wxSvgXmlProperty *prop;

    if (m_properties == NULL)
        return FALSE;

    else if (m_properties->GetName() == name)
    {
        prop = m_properties;
        m_properties = prop->GetNext();
        prop->SetNext(NULL);
        delete prop;
        return TRUE;
    }

    else
    {
        wxSvgXmlProperty *p = m_properties;
        while (p->GetNext())
        {
            if (p->GetNext()->GetName() == name)
            {
                prop = p->GetNext();
                p->SetNext(prop->GetNext());
                prop->SetNext(NULL);
                delete prop;
                return TRUE;
            }
            p = p->GetNext();
        }
        return FALSE;
    }
}

std::wstring wxSvgXmlNode::GetAttribute(const std::wstring& name) {
	std::wstring val;
	GetPropVal(name, &val);
	return val;
}

std::wstring wxSvgXmlNode::GetAttributeNS(const std::wstring& namespaceURI, const std::wstring& localName) {
	return GetAttribute(localName);
}

bool wxSvgXmlNode::SetAttribute(const std::wstring& name, const std::wstring& value) {
	wxSvgXmlProperty *prop = GetProperties();
	while (prop) {
		if (prop->GetName() == name) {
			prop->SetValue(value);
			return true;
		}
		prop = prop->GetNext();
	}
	AddProperty(name, value);
	return true;
}

bool wxSvgXmlNode::SetAttributeNS(const std::wstring& namespaceURI, const std::wstring& qualifiedName, const std::wstring& value) {
	return SetAttribute(qualifiedName, value);
}

void wxSvgXmlNode::RemoveAttribute(const std::wstring& name) {
	DeleteProperty(name);
}

void wxSvgXmlNode::RemoveAttributeNS(const std::wstring& namespaceURI, const std::wstring& localName) {
	RemoveAttribute(localName);
}

bool wxSvgXmlNode::HasAttribute(const std::wstring& name) {
  return HasProp(name);
}

bool wxSvgXmlNode::HasAttributeNS(const std::wstring& namespaceURI, const std::wstring& localName) {
  return HasAttribute(localName);
}

wxSvgXmlAttrHash wxSvgXmlNode::GetAttributes() const {
  wxSvgXmlAttrHash attributes;
  wxSvgXmlProperty *prop = GetProperties();
  while (prop)
  {
    attributes.Add(prop->GetName(), prop->GetValue());
    prop = prop->GetNext();
  }
  return attributes;
}

//-----------------------------------------------------------------------------
//  wxSvgXmlDocument
//-----------------------------------------------------------------------------

wxSvgXmlDocument::wxSvgXmlDocument()
    : m_version(_T("1.0")), m_fileEncoding(_T("utf-8")), m_root(NULL)
{
}

wxSvgXmlDocument::wxSvgXmlDocument(const std::wstring& filename, const std::wstring& encoding)
                          : wxObject(), m_root(NULL)
{
    if ( !Load(filename, encoding) )
    {
        wxDELETE(m_root);
    }
}

wxSvgXmlDocument::wxSvgXmlDocument(const wxSvgXmlDocument& doc)
{
    DoCopy(doc);
}

wxSvgXmlDocument& wxSvgXmlDocument::operator=(const wxSvgXmlDocument& doc)
{
    wxDELETE(m_root);
    DoCopy(doc);
    return *this;
}

void wxSvgXmlDocument::SetRoot(wxSvgXmlNode *node)
{
    delete m_root;
    m_root = node;
    if (m_root)
        m_root->SetOwnerDocument(this);
}

wxSvgXmlElement* wxSvgXmlDocument::CreateElement(const std::wstring& tagName)
{
  return new wxSvgXmlElement(wxSVGXML_ELEMENT_NODE, tagName);
}

wxSvgXmlElement* wxSvgXmlDocument::CreateElementNS(const std::wstring& namespaceURI,
											 const std::wstring& qualifiedName)
{
  return CreateElement(qualifiedName);
}

void wxSvgXmlDocument::DoCopy(const wxSvgXmlDocument& doc)
{
    m_version = doc.m_version;
    m_fileEncoding = doc.m_fileEncoding;
    m_root = new wxSvgXmlNode(*doc.m_root);
}



/*bool wxSvgXmlDocument::Save(const std::wstring& filename) const
{
    if ( !IsOk() )
        return FALSE;

    std::wstring s;

    wxMBConv *convMem = NULL, *convFile = NULL;
#if wxUSE_UNICODE
    convFile = new wxCSConv(GetFileEncoding());
#else
    if ( GetFileEncoding() != GetEncoding() )
    {
        convFile = new wxCSConv(GetFileEncoding());
        convMem = new wxCSConv(GetEncoding());
    }
#endif

    s.Printf(_T("<?xml version=\"%s\" encoding=\"%s\"?>\n"),
        GetVersion().c_str(), GetFileEncoding().c_str());
    OutputString(stream, s, NULL, NULL);

    OutputNode(stream, GetRoot(), 0, convMem, convFile);
    OutputString(stream, _T("\n"), NULL, NULL);

    if ( convFile )
        delete convFile;
    if ( convMem )
        delete convMem;

    return TRUE;
}
*/


//-----------------------------------------------------------------------------
//  wxSvgXmlDocument loading routines
//-----------------------------------------------------------------------------

/*
    FIXME:
       - process all elements, including CDATA
 */

// converts Expat-produced string in UTF-8 into std::wstring.
inline static std::wstring CharToString(const char *s, size_t len = std::wstring::npos)
{
    std::wstring str;
    size_t slen = len;
    if (slen == std::wstring::npos)
    {
        slen = strlen(s);
    }
    
    wchar_t* pBuf = new wchar_t[slen + 1];
    if ( NULL == pBuf )
    {
        return L"";
    }
    size_t out_len = (slen + 1) * sizeof(wchar_t);
    memset(pBuf, 0, (slen + 1) * sizeof(wchar_t));
    wchar_t* pResult = pBuf;
    out_len = ::MultiByteToWideChar(CP_UTF8, 0, s, slen, pBuf, slen * sizeof(wchar_t));
    str.assign( pResult, out_len );

    delete [] pResult;
    pResult = NULL;
    return str;
}

static void StartElementHnd(void *userData, const char *name, const char **atts)
{
    wxSvgXmlParsingContext *ctx = (wxSvgXmlParsingContext*)userData;
	wxSvgXmlElement* node = ctx->doc->CreateElement(CharToString(name));
    const char **a = atts;
    while (*a)
    {
        node->AddProperty(CharToString(a[0]), CharToString(a[1]));
        a += 2;
    }
    if (ctx->root == NULL)
        ctx->root = node;
    else
        ctx->node->AddChild(node);
    ctx->node = node;
    ctx->lastAsText = NULL;
}

static void EndElementHnd(void *userData, const char* WXUNUSED(name))
{
    wxSvgXmlParsingContext *ctx = (wxSvgXmlParsingContext*)userData;

    ctx->node = ctx->node->GetParent();
    ctx->lastAsText = NULL;
}

static void TextHnd(void *userData, const char *s, int len)
{
    wxSvgXmlParsingContext *ctx = (wxSvgXmlParsingContext*)userData;
    char *buf = new char[len + 1];

    buf[len] = '\0';
    memcpy(buf, s, (size_t)len);

    if (ctx->lastAsText)
    {
        ctx->lastAsText->SetContent(ctx->lastAsText->GetContent() +
                                    CharToString(buf));
    }
    else
    {
        bool whiteOnly = TRUE;
        for (char *c = buf; *c != '\0'; c++)
            if (*c != ' ' && *c != '\t' && *c != '\n' && *c != '\r')
            {
                whiteOnly = FALSE;
                break;
            }
        if (!whiteOnly)
        {
            ctx->lastAsText = new wxSvgXmlNode(wxSVGXML_TEXT_NODE, _T("text"),
                                            CharToString(buf));
            ctx->node->AddChild(ctx->lastAsText);
        }
    }

    delete[] buf;
}

static void CommentHnd(void *userData, const char *data)
{
    wxSvgXmlParsingContext *ctx = (wxSvgXmlParsingContext*)userData;

    if (ctx->node)
    {
        // VS: ctx->node == NULL happens if there is a comment before
        //     the root element (e.g. wxDesigner's output). We ignore such
        //     comments, no big deal...
        ctx->node->AddChild(new wxSvgXmlNode(wxSVGXML_COMMENT_NODE,
                            _T("comment"), CharToString(data)));
    }
    ctx->lastAsText = NULL;
}

static void DefaultHnd(void *userData, const char *s, int len)
{
    // XML header:
    if (len > 6 && memcmp(s, "<?xml ", 6) == 0)
    {
        wxSvgXmlParsingContext *ctx = (wxSvgXmlParsingContext*)userData;

        std::wstring buf = CharToString(s, (size_t)len);
        int pos;
        pos = buf.find(_T("encoding="));
        if (pos != std::wstring::npos)
        {
            ctx->encoding = wxStringPort::BeforeFirst(buf.substr(pos + 10), buf[(size_t)pos+9]);
        }
        pos = buf.find(_T("version="));
        if (pos != std::wstring::npos)
        {
            ctx->version = wxStringPort::BeforeFirst(buf.substr(pos + 9), buf[(size_t)pos+8]);
        }
    }
}

#define CP_GBK      (936)       // ��������code page

static void GBK_to_Unicode(const char* in, int len, std::wstring& out)
{
    int wbufferlen = (int)::MultiByteToWideChar(CP_GBK,MB_PRECOMPOSED,in,(int)len,NULL,0);
    wchar_t* pwbuffer = new wchar_t[wbufferlen+4];
    if ( NULL == pwbuffer )
    {
        return;
    }
    wbufferlen = (int)::MultiByteToWideChar(CP_GBK,MB_PRECOMPOSED,in,(int)len,pwbuffer,wbufferlen+2);
    pwbuffer[wbufferlen] = '\0';
    out.assign( pwbuffer, wbufferlen );
    delete[] pwbuffer;
    return;
}

static int XMLConvertGB(void *, const char *s)
{
    //��gb2312ת����ucs2����,���ض�Ӧ��ucs2����ֵ
    //,Ȼ��expat��ѱ���ת����utf-8�����ٴ���parsedata
    std::wstring wstr;
    GBK_to_Unicode(s,2,wstr);
    return wstr[0];
}

static int UnknownEncodingHnd(void * WXUNUSED(encodingHandlerData),
                              const XML_Char *name, XML_Encoding *info)
{
/*    // We must build conversion table for expat. The easiest way to do so
    // is to let wxCSConv convert as string containing all characters to
    // wide character representation:
    std::wstring str(name, wxConvLibc);
    wxCSConv conv(str);
    char mbBuf[2];
    wchar_t wcBuf[10];
    size_t i;

    mbBuf[1] = 0;
    info->map[0] = 0;
    for (i = 0; i < 255; i++)
    {
        mbBuf[0] = (char)(i+1);
        if (conv.MB2WC(wcBuf, mbBuf, 2) == (size_t)-1)
        {
            // invalid/undefined byte in the encoding:
            info->map[i+1] = -1;
        }
        info->map[i+1] = (int)wcBuf[0];
    }

    info->data = NULL;
    info->convert = NULL;
    info->release = NULL;

    return 1;*/
    int i;
    if( !name ||  strcmp(name,"gb2312") )
        return XML_STATUS_ERROR;

    for(i=0;i<128;i++)
        info->map[i] = i;
    for(;i<256;i++)
        info->map[i] = -2;
    info->convert = XMLConvertGB;
    info->release = NULL;
    return XML_STATUS_OK;
}

bool wxSvgXmlDocument::Load(const std::wstring& filename, const std::wstring& encoding) 
{
    if (!wxFuncPort::wxFileExists(filename)) 
    {
        return false;
    }

    char buffer[1024 * 16];
    int readlen;
    bool fSuccess = true;
    FILE* fp;

    fp = _tfopen(filename.c_str(),_T("rb"));

    if(fp == NULL)
    {   
        return false;
    }

    wxSvgXmlParsingContext ctx;
    XML_Parser parser = XML_ParserCreate(NULL);

    ctx.doc = this;
    ctx.root = ctx.node = NULL;
    ctx.encoding = _T("UTF-8"); // default in absence of encoding=""

    XML_SetUserData(parser, (void*)&ctx);
    XML_SetElementHandler(parser, StartElementHnd, EndElementHnd);
    XML_SetCharacterDataHandler(parser, TextHnd);
    XML_SetCommentHandler(parser, CommentHnd);
    XML_SetDefaultHandler(parser, DefaultHnd);
    XML_SetUnknownEncodingHandler(parser, UnknownEncodingHnd, NULL);

    while (!feof (fp) && fSuccess)
    {
        readlen = (int)fread(buffer,(int)sizeof(char),1024 * 16,fp);
        fSuccess = XML_Parse(parser, buffer,readlen,0);
    }

    if (fSuccess)
    {
        if (!ctx.version.empty())
            SetVersion(ctx.version);
        if (!ctx.encoding.empty())
            SetFileEncoding(ctx.encoding);
        SetRoot(ctx.root);
    }
    else
    {
        delete ctx.root;
    }

    fclose(fp);

    XML_ParserFree(parser);
    return fSuccess;
}

//-----------------------------------------------------------------------------
//  wxSvgXmlDocument saving routines
//-----------------------------------------------------------------------------

// write string to output:
/*
inline static void OutputString(wxOutputStream& stream, const std::wstring& str,
#if wxUSE_UNICODE
    wxMBConv * WXUNUSED(convMem),
#else
    wxMBConv *convMem,
#endif
    wxMBConv *convFile)
{
    if (str.empty()) return;
#if wxUSE_UNICODE
    const wxWX2MBbuf buf(str.mb_str(*(convFile ? convFile : &wxConvUTF8)));
    stream.Write((const char*)buf, strlen((const char*)buf));
#else
    if ( convFile == NULL )
        stream.Write(str.mb_str(), str.Len());
    else
    {
        std::wstring str2(str.wc_str(*convMem), *convFile);
        stream.Write(str2.mb_str(), str2.Len());
    }
#endif
}
*/
// Same as above, but create entities first.
// Translates '<' to "&lt;", '>' to "&gt;" and '&' to "&amp;"
/*
static void OutputStringEnt(wxOutputStream& stream, const std::wstring& str,
                            wxMBConv *convMem, wxMBConv *convFile,
                            bool escapeQuotes = false)
{
    std::wstring buf;
    size_t i, last, len;
    wchar_t c;

    len = str.Len();
    last = 0;
    for (i = 0; i < len; i++)
    {
        c = str.GetChar(i);
        if (c == _T('<') || c == _T('>') ||
            (c == _T('&') && str.Mid(i+1, 4) != _T("amp;")) ||
            (escapeQuotes && c == _T('"')))
        {
            OutputString(stream, str.Mid(last, i - last), convMem, convFile);
            switch (c)
            {
                case _T('<'):
                    OutputString(stream, _T("&lt;"), NULL, NULL);
                    break;
                case _T('>'):
                    OutputString(stream, _T("&gt;"), NULL, NULL);
                    break;
                case _T('&'):
                    OutputString(stream, _T("&amp;"), NULL, NULL);
                    break;
                case _T('"'):
                    OutputString(stream, _T("&quot;"), NULL, NULL);
                    break;
                default: break;
            }
            last = i + 1;
        }
    }
    OutputString(stream, str.Mid(last, i - last), convMem, convFile);
}

inline static void OutputIndentation(wxOutputStream& stream, int indent)
{
    std::wstring str = _T("\n");
    for (int i = 0; i < indent; i++)
        str << _T(' ') << _T(' ');
    OutputString(stream, str, NULL, NULL);
}

static void OutputNode(wxOutputStream& stream, wxSvgXmlNode *node, int indent,
                       wxMBConv *convMem, wxMBConv *convFile)
{
    wxSvgXmlNode *n, *prev;
    wxSvgXmlAttrHash attributes;

    switch (node->GetType())
    {
        case wxSVGXML_TEXT_NODE:
            OutputStringEnt(stream, node->GetContent(), convMem, convFile);
            break;

        case wxSVGXML_ELEMENT_NODE:
            OutputString(stream, _T("<"), NULL, NULL);
            OutputString(stream, node->GetName(), NULL, NULL);

            attributes = node->GetAttributes();
            for (wxSvgXmlAttrHash::iterator it = attributes.begin(); it != attributes.end(); ++it) {
                OutputString(stream, _T(" ") + it->GetName() +  _T("=\""), NULL, NULL);
                OutputStringEnt(stream, it->GetValue(), NULL, NULL, true);
                OutputString(stream, _T("\""), NULL, NULL);
            }

            if (node->GetChildren())
            {
                OutputString(stream, _T(">"), NULL, NULL);
                prev = NULL;
                n = node->GetChildren();
                while (n)
                {
                    if (n && n->GetType() != wxSVGXML_TEXT_NODE && node->GetAttribute(_T("xml:space")) != _T("preserve"))
                        OutputIndentation(stream, indent + 1);
                    OutputNode(stream, n, indent + 1, convMem, convFile);
                    prev = n;
                    n = n->GetNext();
                }
                if (prev && prev->GetType() != wxSVGXML_TEXT_NODE)
                    OutputIndentation(stream, indent);
                OutputString(stream, _T("</"), NULL, NULL);
                OutputString(stream, node->GetName(), NULL, NULL);
                OutputString(stream, _T(">"), NULL, NULL);
            }
            else
                OutputString(stream, _T("/>"), NULL, NULL);
            break;

        case wxSVGXML_COMMENT_NODE:
            OutputString(stream, _T("<!--"), NULL, NULL);
            OutputString(stream, node->GetContent(), convMem, convFile);
            OutputString(stream, _T("-->"), NULL, NULL);
            break;

        default:
            wxFAIL_MSG(_T("unsupported node type"));
    }
}
*/