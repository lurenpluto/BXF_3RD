//////////////////////////////////////////////////////////////////////////////
// Name:        SVGColor.cpp
// Purpose:     
// Author:      Alex Thuering
// Created:     2005/04/29
// RCS-ID:      $Id: SVGColor.cpp,v 1.3 2005/06/07 22:30:30 ntalex Exp $
// Copyright:   (c) 2005 Alex Thuering
// Licence:     wxWindows licence
//////////////////////////////////////////////////////////////////////////////

#include "SVGColor.h"

std::wstring wxSVGColor::GetCSSText() const
{
  if (m_colorType == wxSVG_COLORTYPE_UNKNOWN)
	return _T("");
  return wxStringPort::Format(_T("#%02x%02x%02x"),
	m_rgbColor.Red(), m_rgbColor.Green(), m_rgbColor.Blue());
}
	
void wxSVGColor::SetRGBColor(const wxRGBColor& rgbColor)
{
  m_rgbColor = rgbColor;
  m_colorType = wxSVG_COLORTYPE_RGBCOLOR;
}

void wxSVGColor::SetICCColor(const wxSVGICCColor& iccColor)
{
  m_iccColor = iccColor;
  m_colorType = wxSVG_COLORTYPE_RGBCOLOR_ICCCOLOR;
}

void wxSVGColor::SetRGBColor(const std::wstring& rgbColor)
{

}

void wxSVGColor::SetRGBColorICCColor(const std::wstring& rgbColor, const std::wstring& iccColor)
{

}

void wxSVGColor::SetColor(wxSVG_COLORTYPE colorType, const std::wstring& rgbColor, const std::wstring& iccColor)
{

}
